
import { createClient } from '@supabase/supabase-js';

// Thay thế các giá trị này bằng thông tin từ Supabase Dashboard của bạn
const SUPABASE_URL = 'https://YOUR_PROJECT_ID.supabase.co';
const SUPABASE_ANON_KEY = 'YOUR_ANON_KEY';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
